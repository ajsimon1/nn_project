print("you just imported foo from %s" % __file__)
