#!/usr/bin/python2.4
print("I'm baz - not executable")
