#!/usr/bin/python2.5
print("I'm bar")
