#!/usr/bin/python
print("I'm bar")
